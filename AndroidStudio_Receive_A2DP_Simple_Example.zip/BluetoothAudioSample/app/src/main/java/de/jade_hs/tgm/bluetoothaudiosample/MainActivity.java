package de.jade_hs.tgm.bluetoothaudiosample;

import android.bluetooth.BluetoothA2dp;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothServerSocket;
import android.bluetooth.BluetoothSocket;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioRecord;
import android.media.AudioTrack;
import android.media.MediaRecorder;
import android.os.Handler;
import android.os.Message;
import android.os.SystemClock;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.UUID;

public class MainActivity extends AppCompatActivity {

    private AudioRecord recorder = null;
    private static final int RECORDER_SAMPLERATE = 44100;
    private static final int RECORDER_CHANNELS = AudioFormat.CHANNEL_IN_STEREO;
    private static final int RECORDER_AUDIO_ENCODING = AudioFormat.ENCODING_PCM_16BIT;
    private int BufferElements2Rec = 1024; // want to play 2048 (2K) since 2 bytes we use only 1024
    private int BytesPerElement = 2; // 2 bytes in 16bit format
    private boolean isRecording = false;
    private Thread recordingThread = null;
    private AudioTrack audioTrack;
    private BluetoothAdapter mBluetoothAdapter;
    private UUID MY_UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");
    private static final String TAG = "MY_APP_DEBUG_TAG";
    private Handler mHandler; // handler that gets info from Bluetooth service
    private interface MessageConstants {
        public static final int MESSAGE_READ = 0;
        public static final int MESSAGE_WRITE = 1;
        public static final int MESSAGE_TOAST = 2;

        // ... (Add other message types here as needed.)
    }

    private final static int MESSAGE_READ = 2;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        audioTrack = new AudioTrack(
                AudioManager.STREAM_MUSIC,
                RECORDER_SAMPLERATE,
                RECORDER_CHANNELS,
                RECORDER_AUDIO_ENCODING,
                BufferElements2Rec,
                AudioTrack.MODE_STREAM);

        System.out.println(mBluetoothAdapter.getProfileConnectionState(BluetoothA2dp.SAP));
        System.out.println(mBluetoothAdapter.getProfileConnectionState(BluetoothA2dp.HEALTH));
        System.out.println(mBluetoothAdapter.getProfileConnectionState(BluetoothA2dp.GATT_SERVER));
        System.out.println(mBluetoothAdapter.getProfileConnectionState(BluetoothA2dp.GATT));
        System.out.println(mBluetoothAdapter.getProfileConnectionState(BluetoothA2dp.A2DP));
        System.out.println(mBluetoothAdapter.getProfileConnectionState(BluetoothA2dp.HEADSET));

        Button button = (Button)findViewById(R.id.button_id);
        button.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if (!isRecording) {
                    if (!mBluetoothAdapter.isEnabled())
                    {
                        Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
                        int REQUEST_ENABLE_BT = 1;
                        startActivityForResult(enableBtIntent, REQUEST_ENABLE_BT);
                    }
                    if (mBluetoothAdapter.isEnabled())
                    {
                        ((Button)v).setText("Stop playing...");
                        startRecording();
                        audioTrack.play();
                    }
                }
                else {
                    disableButton();
                }
            }
        });

        getApplicationContext().registerReceiver(mReceiver,
                new IntentFilter(BluetoothDevice.ACTION_ACL_CONNECTED));
        getApplicationContext().registerReceiver(mReceiver,
                new IntentFilter(BluetoothDevice.ACTION_ACL_DISCONNECTED));
    }

    @Override
    protected void onDestroy()
    {
        disableButton();
        System.out.println("Destroy");
        super.onDestroy();
    }

    private void startRecording()
    {
        recorder = new AudioRecord(MediaRecorder.AudioSource.MIC,
                RECORDER_SAMPLERATE, RECORDER_CHANNELS,
                RECORDER_AUDIO_ENCODING, BufferElements2Rec * BytesPerElement);
        if (recorder.getState() == AudioRecord.STATE_INITIALIZED) {
            recorder.startRecording();
            isRecording = true;
            recordingThread = new Thread(new Runnable() {
                public void run() {
                    writeAudioDataToFile();
                }

            }, "AudioRecorder Thread");
            recordingThread.start();
        }
        else
        {
            disableButton();
            Toast.makeText(MainActivity.this, "Unable to initialize AudioRecord! (Restart Phone?)", Toast.LENGTH_LONG).show();
        }
    }

    private void writeAudioDataToFile() {
        short sData[] = new short[BufferElements2Rec];
        while (isRecording) {
            // gets the voice output from microphone to byte format
            recorder.read(sData, 0, BufferElements2Rec);
            audioTrack.write(sData, 0, BufferElements2Rec);
        }
    }

    private void disableButton()
    {
        if (isRecording) {
            recorder.stop();
            recorder.release();
            recorder = null;
            recordingThread = null;
        }
        isRecording = false;
        Button button = (Button) findViewById(R.id.button_id);
        button.setText("Start playing...");
    }

    private final BroadcastReceiver mReceiver = new BroadcastReceiver() {
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            BluetoothDevice device = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
            if (isRecording) {
                disableButton();
                Toast.makeText(MainActivity.this, "Connection lost to A2DP Device!", Toast.LENGTH_LONG).show();
            }
            if (BluetoothDevice.ACTION_FOUND.equals(action)) {
                System.out.println("Device found");
                //device.setPairingConfirmation()
            }
            else if (BluetoothDevice.ACTION_ACL_CONNECTED.equals(action)) {
                System.out.println(device.getName());
                System.out.println("Device is now connected");
            }
            else if (BluetoothAdapter.ACTION_DISCOVERY_FINISHED.equals(action)) {
                System.out.println("Done searching");
            }
            else if (BluetoothDevice.ACTION_ACL_DISCONNECT_REQUESTED.equals(action)) {
                System.out.println("Device is about to disconnect");
            }
            else if (BluetoothDevice.ACTION_ACL_DISCONNECTED.equals(action)) {
                System.out.println("Device has disconnected");
            }
        }
    };
}



